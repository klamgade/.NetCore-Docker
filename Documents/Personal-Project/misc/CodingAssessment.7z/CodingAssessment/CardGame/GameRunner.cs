using System;
namespace CardGame
{
    class GameRunner
    {
        static void Main(string[] args)
        {
            Deck deckOne = new Deck();
            deckOne.Shuffle();
            for(int i = 0; i < 52; i++)
            {
                Console.Write("{0, -19}", deckOne.DealCard().ToString());
                if ((i + 1) % 4 == 0)
                    Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}

/*
Structure:
 - Card class is the entity that is used out from the Deck. Card has a Face (range from Ace to Kind) and Suit(4 types) properties.
 - Deck class represent the collection of cards which has a logic to shuffle cards action and an action to deal it to all four players.
 - GameRunner class runs the actual game where it currently generate a new deck, shuffle it and deal the cards to all four players.

Environment and futher work:
 - To develop this card game, a C# console app is built based on Asp.NET Core open-source framework and on Object Oriented Programming Paradigm.
 - Further work on this can be done to actually play a game providing a logic based on the chosen game rules as an actions or methods and creating a class for any major entities like Player, etc. 
 - Based on the particular actions from the game rules an output or a result of the game can be displayed accordingly.  
*/
