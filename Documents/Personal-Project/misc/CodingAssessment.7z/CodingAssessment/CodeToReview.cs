﻿using System;
//import for system Collections has a typo 
using System.Collegctions.Generic;
using System.Linq;

namespace Utility.Valocity.ProfileHelper
{
    //it would be good to extract the People class and its properties to a separate file 
    public class People
    {
    //static should be removed because the value should be dynamic everytime a new person is created
     private static readonly DateTimeOffset Under16 = DateTimeOffset.UtcNow.AddYears(-15);
     //good not to have the private set if it is a read-only immutable value
     public string Name { get; private set; }
     //good to provide a descriptive property name instead of abbreviation
     public DateTimeOffset DOB { get; private set; }
     public People(string name) : this(name, Under16.Date) { }
     public People(string name, DateTime dob) {
         Name = name;
         DOB = dob;
     }}

    //the methods below can be moved to an interface, helps in decoupling and writing tests
    public class BirthingUnit
    {
        // description is not required and good to have the property name self-descriptive
        /// <summary>
        /// MaxItemsToRetrieve
        /// </summary>
        private List<People> _people;

        public BirthingUnit()
        {
            _people = new List<People>();
        }

        /// <summary>
        /// GetPeoples  //bit more descriptive summary would be good
        /// </summary>
        /// <param name="j"></param> //param name is a character 'i' in this method which doesn't match and also good to have bit self-descriptive variable name for it 
        /// <returns>List<object></returns>  // it would be good to have more readable descritpion (e.g. returns a list of people) and also worth mentioning the return type than just object.
        public List<People> GetPeople(int i) //good to have a parameter with self-descriptive name
        {
            for (int j = 0; j < i; j++)
            {
                try
                {
                    // Creates a dandon Name //typo on random
                    string name = string.Empty;
                    var random = new Random(); //initialize random above the scope of for loop which avoids initalizing it in every iteration
                    if (random.Next(0, 1) == 0) { //it returns a random with min and max range where the value is always less than max value which will always return 0. hence it can be refactored to random.Next(0, 2) == 0) 
                        name = "Bob";
                    }
                    else {
                        name = "Betty";
                    }
                    // Adds new people to the list  (not required, already self-descritpion function name)
                    _people.Add(new People(name, DateTime.UtcNow.Subtract(new TimeSpan(random.Next(18, 85) * 356, 0, 0, 0))));
                }
                catch (Exception e)
                {
                    //it would be good to log the error and also to provide a description and specific exception message instead of something failed
                    //also can create and throw a custom exception something failied to create user exception which can be helpful in debugging in future
                    // Dont think this should ever happen (there is a possibility for the exception to occur and the comment isn't a very helpful comment in this case)
                    throw new Exception("Something failed in user creation");
                }
            }
            return _people;
        }

//it would be better to turn this into a generic function and pass name and age limit variable as params and based on it a filter for Bob or Betty can be done
        private IEnumerable<People> GetBobs(bool olderThan30)
        {
            return olderThan30 ? _people.Where(x => x.Name == "Bob" && x.DOB >= DateTime.Now.Subtract(new TimeSpan(30 * 356, 0, 0, 0))) : _people.Where(x => x.Name == "Bob");
        }

//the return value (i.e full name) and the logic of the method is not very clear what it is trying to achieve.
        public string GetMarried(People p, string lastName)
        {
            if (lastName.Contains("test"))
                return p.Name;
            if ((p.Name.Length + lastName).Length > 255) //adding the length of name and lastname isn't correct, should be something like ((p.Name.Length + lastName.Length) > 255)
            {
                (p.Name + " " + lastName).Substring(0, 255); // the value after sub string isn't stored neither returned which isn't clear on the purpose of doing it
            }

            return p.Name + " " + lastName;
        }
    }
}