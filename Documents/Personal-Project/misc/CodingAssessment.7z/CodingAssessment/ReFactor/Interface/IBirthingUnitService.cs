using Refactor;
using System.Collections.Generic;

namespace ReFactor.Interface
{
    public interface IBirthingUnitService
    {
        void CreatePerson(int numberOfPeople);
        IEnumerable<Person> GetPersons(string firstName, int olderThan);
    }
}