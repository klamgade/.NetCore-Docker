using System;

namespace Refactor
{
    public class Person
    {
        private readonly DateTimeOffset Under16 = DateTimeOffset.UtcNow.AddYears(-15);
        public string FirstName { get; }
        public DateTimeOffset DateOfBirth { get; }

        public Person(string firstName)
        {
            FirstName = firstName;
            DateOfBirth = Under16.Date;
        }

        public Person(string firstName, DateTime dateOfBirth)
        {
            FirstName = firstName;
            DateOfBirth = dateOfBirth;
        }

        public string GetPersonFullName(string firstName, string lastName)
        {
            int maxNameLength = 255;
            if (string.IsNullOrWhiteSpace(lastName))
                return firstName;
            var fullName = firstName + " " + lastName;
            if (fullName.Length > maxNameLength)
                return fullName.Substring(0, maxNameLength);
            return fullName;
        }
    }
}
