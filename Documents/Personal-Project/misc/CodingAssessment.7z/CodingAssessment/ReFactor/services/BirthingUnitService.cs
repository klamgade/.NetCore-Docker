﻿using ReFactor.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Refactor.Services
{
 
    public class BirthingUnitService : IBirthingUnitService
    {
        private List<Person> _peopleList;

        public BirthingUnitService()
        {
            _peopleList = new List<Person>();
        }

        public void CreatePerson(int numberOfPeople)
        {
            var random = new Random();
            for (int j = 0; j < numberOfPeople; j++)
            {
                try
                {
                    string name = string.Empty;
                    if (random.Next(0, 2) == 0)
                    {
                        name = "Bob";
                    }
                    else
                    {
                        name = "Betty";
                    }
                    _peopleList.Add(new Person(name, DateTime.UtcNow.Subtract(new TimeSpan(random.Next(18, 85) * 365, 0, 0, 0))));
                }
                catch (Exception exception)
                {
                    throw new Exception("Creating person failed", exception);
                }
            }
        }

        public IEnumerable<Person> GetPersons(string firstName, int olderThan)
        {
            return _peopleList.Where(p => p.FirstName.Equals(firstName, StringComparison.OrdinalIgnoreCase) && p.DateOfBirth >= DateTime.Now.Subtract(new TimeSpan(olderThan * 365, 0, 0, 0)));
        }
    }
}